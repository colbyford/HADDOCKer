Docker containers folder
