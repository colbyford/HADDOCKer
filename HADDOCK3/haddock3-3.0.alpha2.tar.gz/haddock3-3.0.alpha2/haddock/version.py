"""This software version"""

MAJOR = "3"
MINOR = "0"
PATCH = "alpha"
RELEASE = "2"

CURRENT_VERSION = f"{MAJOR}.{MINOR}.{PATCH}-{RELEASE}"